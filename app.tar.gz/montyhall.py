import flet as ft
import random

def main(page: ft.Page):
    # --- CONFIGURACIÓN DEL SHOW ---
    page.title = "Trato Hecho: La Paradoja de Monty Hall"
    page.theme_mode = "dark"
    page.horizontal_alignment = "center"
    page.vertical_alignment = "center"
    page.bgcolor = "#1a1a2e" # Tono oscuro de estudio de TV
    page.window_width = 600
    page.window_height = 700

    # Diccionario para manejar el estado lógico del juego sin enredarnos
    state = {
        "prize": "",
        "winning_door": -1,
        "user_choice": -1,
        "host_opened": -1,
        "stage": 0 # 0: Input, 1: Primera elección, 2: Cambiar/Mantener, 3: Final
    }

    # --- ELEMENTOS DE LA UI ---
    title_text = ft.Text("📺 ¡EL GRAN SHOW DE MONTY HALL! 📺", size=28, weight="bold", color="#e94560")
    subtitle_text = ft.Text("¿Por qué premio estamos jugando hoy?", size=18, text_align="center")
    
    prize_input = ft.TextField(
        label="Ej: Ticket VIP para Soda Stereo", 
        width=350, 
        text_align="center",
        border_color="#e94560"
    )
    
    doors_row = ft.Row(alignment="center", spacing=20)

    # --- LÓGICA DEL JUEGO ---
    def start_game(e):
        if not prize_input.value:
            prize_input.error_text = "¡El público exige un premio!"
            page.update()
            return
            
        state["prize"] = prize_input.value
        state["winning_door"] = random.randint(0, 2) # Esconde el premio en 0, 1 o 2
        state["stage"] = 1
        
        subtitle_text.value = f"¡Excelente! Hemos escondido tu '{state['prize']}' detrás de una puerta.\nLas otras dos tienen CABRAS. 🐐\n\n¡Elige tu puerta!"
        
        # Limpiar pantalla y mostrar puertas
        doors_row.controls.clear()
        for i in range(3):
            door = ft.Container(
                content=ft.Text(f"Puerta {i+1}", size=24, weight="bold", color=ft.colors.WHITE),
                width=140, height=220, bgcolor="#0f3460",
                alignment=ft.alignment.center,
                border_radius=10,
                border=ft.border.all(3, "#0f3460"),
                on_click=lambda e, index=i: door_clicked(index)
            )
            doors_row.controls.append(door)
            
        page.controls.clear()
        page.add(title_text, subtitle_text, doors_row)
        page.update()

    def door_clicked(index):
        # ETAPA 1: El usuario elige su primera puerta
        if state["stage"] == 1:
            state["user_choice"] = index
            
            # Monty abre una puerta (no puede ser la que elegiste, ni la ganadora)
            available_to_open = [i for i in range(3) if i != index and i != state["winning_door"]]
            state["host_opened"] = random.choice(available_to_open) # Elige una de las cabras disponibles
            
            # Actualizamos la puerta que abrió Monty
            doors_row.controls[state["host_opened"]].bgcolor = ft.colors.RED_900
            doors_row.controls[state["host_opened"]].content = ft.Text("🐐\nCABRA", size=24, text_align="center")
            doors_row.controls[state["host_opened"]].on_click = None # Desactivar clic
            
            # Resaltar la puerta del usuario
            doors_row.controls[index].border = ft.border.all(5, ft.colors.YELLOW_600)
            
            subtitle_text.value = f"¡Atención! Elegiste la Puerta {index+1}.\nPero yo como presentador, abro la Puerta {state['host_opened']+1} y ¡hay una cabra!\n\n¿Te quedas con tu puerta o cambias a la otra cerrada?"
            state["stage"] = 2
            page.update()
            
        # ETAPA 2: El usuario decide si cambiar o mantenerse
        elif state["stage"] == 2:
            if index == state["host_opened"]:
                return # No puede elegir la puerta que ya está abierta
                
            final_choice = index
            state["stage"] = 3
            
            # Gran revelación
            for i in range(3):
                doors_row.controls[i].border = None
                if i == state["winning_door"]:
                    doors_row.controls[i].bgcolor = ft.colors.GREEN_700
                    doors_row.controls[i].content = ft.Text(f"🎉\n{state['prize']}", size=18, text_align="center", weight="bold")
                else:
                    doors_row.controls[i].bgcolor = ft.colors.RED_900
                    doors_row.controls[i].content = ft.Text("🐐\nCABRA", size=24, text_align="center")
                    
            # Resaltar la elección final del usuario
            doors_row.controls[final_choice].border = ft.border.all(6, ft.colors.WHITE)
            
            # --- LÓGICA DE VERDICTO CON HUMOR ESTADÍSTICO ---
            if final_choice == state["winning_door"]:
                if final_choice == state["user_choice"]:
                    # Ganó quedándose con su puerta (33.3% de probabilidad)
                    subtitle_text.value = "¡Felicidades! Esta vez tuviste suerte, pero que sepas que Gauss te odia por ignorar la estadística."
                    subtitle_text.color = ft.colors.AMBER_400
                else:
                    # Ganó cambiando de puerta (66.6% de probabilidad)
                    subtitle_text.value = "¡LOGRADO! Cambiaste de puerta y la matemática te recompensó. ¡Disfruta tu premio!"
                    subtitle_text.color = ft.colors.GREEN_400
            else:
                if final_choice == state["user_choice"]:
                    subtitle_text.value = "Perdiste... y lo peor es que la estadística te lo advirtió. ¡Disfruta la cabra!"
                else:
                    subtitle_text.value = "Rayos, estabas en ese 33% de mala suerte donde cambiar no servía. ¡A la próxima!"
                subtitle_text.color = ft.colors.RED_400
                
            page.add(reset_btn)
            page.update()

    def reset_game(e):
        # Reiniciar todas las variables
        state["stage"] = 0
        state["prize"] = ""
        state["winning_door"] = -1
        state["user_choice"] = -1
        state["host_opened"] = -1
        
        prize_input.value = ""
        prize_input.error_text = None
        subtitle_text.value = "¿Por qué premio estamos jugando hoy?"
        subtitle_text.color = ft.colors.WHITE
        
        page.controls.clear()
        page.add(title_text, subtitle_text, prize_input, start_btn)
        page.update()

    # Botones principales
    start_btn = ft.ElevatedButton("¡Que comience el juego!", on_click=start_game, color=ft.colors.WHITE, bgcolor="#e94560")
    reset_btn = ft.ElevatedButton("Jugar otra vez", on_click=reset_game, icon=ft.icons.RESTART_ALT)

    # Añadir elementos iniciales a la página
    page.add(title_text, subtitle_text, prize_input, start_btn)

# Ejecutar la app
ft.app(target=main)